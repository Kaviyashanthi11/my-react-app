import React from "react";
import PropTypes from "prop-types";
import { FormSelect } from "react-bootstrap";

const CustomSelect = React.forwardRef(
  (
    { label, name, value, onChange, options = [], star = false, disabled },
    ref
  ) => {
    return (
      <div
        style={{ display: "flex", alignItems: "center", marginBottom: "16px" }}
      >
        <label style={{ flex: "1", marginBottom: "0" }}>
          {label} {star && <span style={{ color: "red" }}>*</span>}
        </label>
        <div style={{ flex: "1.57", width: "100%" }}>
          <FormSelect
            fullWidth
            ref={ref} // Use the ref passed from the parent
            name={name}
            value={value}
            onChange={onChange}
            disabled={disabled}
            style={{
              border: "1px solid lightgrey",
              borderRadius: "4px",
              height: "25px", // Maintain the desired height
              width: "100%",
              fontSize: "0.8rem", // Use a smaller font size to fit better
              padding: "0 5px", // Reduce padding to avoid text clipping
              lineHeight: "1.2", // Adjust line height if necessary
              overflow: "hidden", // Ensure text does not overflow
              whiteSpace: "nowrap", // Prevent text wrapping
              textOverflow: "ellipsis" // Add ellipsis for overflow text
            }}
          >
            {options.map(option =>
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            )}
          </FormSelect>
        </div>
      </div>
    );
  }
);

// Define PropTypes for type checking
CustomSelect.propTypes = {
  label: PropTypes.string.isRequired,
  name: PropTypes.string.isRequired,
  value: PropTypes.string.isRequired,
  onChange: PropTypes.func.isRequired,
  options: PropTypes.arrayOf(
    PropTypes.shape({
      value: PropTypes.string.isRequired,
      label: PropTypes.string.isRequired
    })
  ),
  star: PropTypes.bool,
  disabled: PropTypes.bool
};

// Export the component with ref forwarding
export default CustomSelect;
