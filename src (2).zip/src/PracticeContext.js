// PracticeContext.js
import React, { createContext, useContext, useState } from 'react';

const PracticeContext = createContext();

export const PracticeProvider = ({ children }) => {
  const [practiceInfo, setPracticeInfo] = useState({ label: '', practiceCode: '' });

  const updatePractice = (practice) => {
    setPracticeInfo(practice);
  };

  return (
    <PracticeContext.Provider value={{ practiceInfo, updatePractice }}>
      {children}
    </PracticeContext.Provider>
  );
};

export const usePractice = () => {
  return useContext(PracticeContext);
};
