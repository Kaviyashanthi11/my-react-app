export const specialities = [
  { name: "Cardiology", value: "cardiology" },
  { name: "Dermatology", value: "dermatology" },
  { name: "Endocrinology", value: "endocrinology" },
  { name: "Gastroenterology", value: "gastroenterology" },
  { name: "Hematology", value: "hematology" },
  { name: "Neurology", value: "neurology" },
  { name: "Oncology", value: "oncology" },
  { name: "Pediatrics", value: "pediatrics" },
  { name: "Psychiatry", value: "psychiatry" },
  { name: "Radiology", value: "radiology" },
  { name: "Surgery", value: "surgery" },
];
