const   searchoption = [
  { value: "4", label: "Member ID,DOB" },
  { value: "2", label: "Member ID,DOB,Last name" },
  {
    value: "1",
    label: "Member ID,First name,Last name,DOB",
  },
  {
    value: "5",
    label: "Member ID,First name,Last name,Group number,DOB",
  },
  {
    value: "3",
    label: "Member ID,First name,Last name",
  },
];

export default searchoption;
