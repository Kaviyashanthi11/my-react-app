import React from "react";
import Layout from "../src/Top/Layout";
const ClientApproval = () => {
  return (
    <div>
      <Layout>Client</Layout>
    </div>
  );
};

export default ClientApproval;
