import React from "react";
import { Routes, Route } from "react-router-dom";
import LoginForm from "./LoginForm";
import ClientApproval from "./ClientApproval";
import EligibilityPayerMaster from "./Masters/EligibilityPayerMaster";
import EligibilityPayerEnrollment from "./Masters/EligibilityPayerEnrollment";
import ClaimStatusPayerMaster from "./Masters/ClaimStatusPayerMaster";
import EnhancedClaimStatus from "./Masters/EnhancedClaimStatus";
import PracticeProviderManagement from "./Masters/PracticeProviderManagement";
import PlanMaster from "./Masters/PlanMaster";
import RateCategory from "./Masters/RateCategory";
import ClearingHouse from "./Masters/ClearingHouse";
import ClaimStatusEnrollment from "./Masters/ClaimStatusEnrollment";
import PrivateRoute from "./PrivateRoute";
import ResetPasswordForm from "./ForgotPassword";
import UserManagement from "./Masters/UserManagement";
import WeeklyTransaction from "./Masters/WeeklyTransaction";
import UserMaster from "./Masters/UserMaster";
import ActivePremiumCustomer from "./Reports/ActivePremiumCustomer";
import ActiveTrial from "./Reports/ActiveTrial";
import InactiveCustomer from "./Reports/InactiveCustomer";
import MaintenanceMaster from "./Masters/MaintenanceMaster";
import HolidayMaster from "./Masters/HolidayMaster";
import ClaimStatusMapping from "./Masters/ClaimStatusMapping";
import PracticeBilling from "./PracticeBilling";
import UserManagement2 from "./User2/UserManage";
import Dashboard from "./User4/Dashboard";
import SuspendedClaim from "./Reports/SuspendedClaim";
import Batchwise from "./Reports/Batchwise";

const AppRoutes = () => {
  return (
    <Routes>
      <Route path="/" element={<LoginForm />} />
      <Route
        path="/client"
        element={
          <PrivateRoute>
            <ClientApproval />
          </PrivateRoute>
        }
      />
      <Route
        path="/reset"
        element={
          <PrivateRoute>
            <ResetPasswordForm />
          </PrivateRoute>
        }
      />
      <Route
        path="/eligibility"
        element={
          <PrivateRoute>
            <EligibilityPayerMaster />
          </PrivateRoute>
        }
      />
      <Route
        path="/enrollment"
        element={
          <PrivateRoute>
            <EligibilityPayerEnrollment />
          </PrivateRoute>
        }
      />
      <Route
        path="/claim"
        element={
          <PrivateRoute>
            <ClaimStatusPayerMaster />
          </PrivateRoute>
        }
      />
      <Route
        path="/enhanced"
        element={
          <PrivateRoute>
            <EnhancedClaimStatus />
          </PrivateRoute>
        }
      />
      <Route
        path="/practice"
        element={
          <PrivateRoute>
            <PracticeProviderManagement />
          </PrivateRoute>
        }
      />
      <Route
        path="/plan"
        element={
          <PrivateRoute>
            <PlanMaster />
          </PrivateRoute>
        }
      />
      <Route
        path="/rate"
        element={
          <PrivateRoute>
            <RateCategory />
          </PrivateRoute>
        }
      />
      <Route
        path="/clearing"
        element={
          <PrivateRoute>
            <ClearingHouse />
          </PrivateRoute>
        }
      />
      <Route
        path="/claimenrollment"
        element={
          <PrivateRoute>
            <ClaimStatusEnrollment />
          </PrivateRoute>
        }
      />
      <Route
        path="/usermanage"
        element={
          <PrivateRoute>
            <UserManagement />
          </PrivateRoute>
        }
      />
      <Route
        path="/weekly"
        element={
          <PrivateRoute>
            <WeeklyTransaction />
          </PrivateRoute>
        }
      />
      <Route
        path="/user"
        element={
          <PrivateRoute>
            <UserMaster />
          </PrivateRoute>
        }
      />
      <Route
        path="/activepre"
        element={
          <PrivateRoute>
            <ActivePremiumCustomer />
          </PrivateRoute>
        }
      />
      <Route
        path="/activetrial"
        element={
          <PrivateRoute>
            <ActiveTrial />
          </PrivateRoute>
        }
      />
      <Route
        path="/inactive"
        element={
          <PrivateRoute>
            <InactiveCustomer />
          </PrivateRoute>
        }
      />
      <Route
        path="/maintenance"
        element={
          <PrivateRoute>
            <MaintenanceMaster />
          </PrivateRoute>
        }
      />
      <Route
        path="/holiday"
        element={
          <PrivateRoute>
            <HolidayMaster />
          </PrivateRoute>
        }
      />
      <Route
        path="/claimmap"
        element={
          <PrivateRoute>
            <ClaimStatusMapping />
          </PrivateRoute>
        }
      />
      <Route
        path="/practicebilling"
        element={
          <PrivateRoute>
            <PracticeBilling />
          </PrivateRoute>
        }
      />
      <Route
        path="/admin/user-management"
        element={
          <PrivateRoute>
            <UserManagement2 />
          </PrivateRoute>
        }
      />
      <Route
        path="/dashboard"
        element={
          <PrivateRoute>
            <Dashboard />
          </PrivateRoute>
        }
      />
      <Route
        path="/reports/suspended-list-claim-Status"
        element={
          <PrivateRoute>
            <SuspendedClaim />
          </PrivateRoute>
        }
      />
      <Route
        path="batch-wise"
        element={
          <PrivateRoute>
            <Batchwise />
          </PrivateRoute>
        }
      />
    </Routes>
  );
};

export default AppRoutes;
