import React from "react";
import Layout from "../Top/Layout";

function Dashboard() {
  return (
    <Layout>
      <div>DASHBOARD</div>
    </Layout>
  );
}

export default Dashboard;
