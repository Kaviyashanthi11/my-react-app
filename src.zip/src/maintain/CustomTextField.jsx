import { FormControl, FormGroup, FormLabel } from "react-bootstrap";
import React, { useEffect } from "react";

// Forward ref to allow parent component to set focus
const CustomTextField = React.forwardRef(
  ({ label, name, value, onChange, star = false, disabled }, ref) => {
    // Focus the input field when it mounts
    useEffect(
      () => {
        // Check if ref is defined and current is not null
        if (ref && ref.current) {
          ref.current.focus();
        }
      },
      [ref]
    );

    return (
      <FormGroup
        style={{ display: "flex", alignItems: "center", marginBottom: "16px" }}
      >
        <FormLabel style={{ flex: "1", marginBottom: "0" }}>
          {label} {star && <span style={{ color: "red" }}>*</span>}
        </FormLabel>
        <FormControl
          ref={ref} // Forward the ref to the input
          type="text"
          name={name}
          value={value}
          onChange={onChange}
          disabled={disabled}
          style={{
            flex: "1.6",
            width: "100%",
            marginLeft: "8px",
            height: "25px",
            border: "1px solid lightgrey",
            borderRadius: "4px"
          }}
        />
      </FormGroup>
    );
  }
);

export default CustomTextField;
