import React, { useRef } from "react";
import { TextField, InputAdornment, IconButton } from "@mui/material";
import SearchIcon from "@mui/icons-material/Search";
import useMediaQuery from "@mui/material/useMediaQuery";

const CustomSearch = ({ searchText, handleSearchTextChange }) => {
  const inputRef = useRef(null);
  // Media query for small screens
  const isSmallScreen = useMediaQuery("(max-width:600px)");
  return (
    <TextField
      variant="outlined"
      value={searchText}
      onChange={handleSearchTextChange}
      size="small"
      style={{
        width: isSmallScreen ? "25%" : "20%", // Reduce width for both screen sizes
        marginTop: isSmallScreen ? "-35px" : "-40px",
        marginLeft: isSmallScreen ? "290px" : "950px",
        
      }}
      InputProps={{
        style: {
          height: "30px", // Reduce the height of the TextField
          fontSize: "15px" // Reduce the font size inside the TextField
        },
        endAdornment: (
          <InputAdornment position="end">
            <IconButton
              size="small"
              aria-label="search"
              onClick={() => {
                if (inputRef.current) {
                  console.log("Search triggered");
                  // Perform search logic here
                }
              }}
            >
              <SearchIcon />
            </IconButton>
          </InputAdornment>
        )
      }}
      fullWidth
      inputRef={inputRef}
    />
  );
};

export default CustomSearch;
