import React from "react";
import { FormControl, FormGroup, FormLabel } from "react-bootstrap";

const CustomTextArea = ({
  label,
  name,
  value,
  onChange,
  rows = 3,
  star = false
}) =>
  <FormGroup
    style={{ display: "flex", alignItems: "center", marginBottom: "16px" }}
  >
    <FormLabel style={{ flex: "0.98", marginBottom: "0" }}>
      {label} {star && <span style={{ color: "red" }}>*</span>}
    </FormLabel>
    <FormControl
      as="textarea"
      name={name}
      value={value}
      onChange={e => {
        console.log("Event:", e); // Debugging: Log the event object
        if (e.target) {
          onChange(e.target.name, e.target.value);
        } else {
          console.error("Event target is undefined");
        }
      }}
      rows={rows}
      style={{
        flex: "1.55",
        width: "100%", // Adjust width as needed
        marginLeft: "8px",
        height: "45px",
        border: "1px solid lightgrey",
        borderRadius: "4px"
      }}
    />
  </FormGroup>;

export default CustomTextArea;
