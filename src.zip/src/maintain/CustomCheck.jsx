import React from 'react';
import Checkbox from '@mui/material/Checkbox';
import FormControlLabel from '@mui/material/FormControlLabel';

const CustomCheckbox = ({ label, checked, onChange, star, name, value }) => (
  <div style={{ display: 'flex', alignItems: 'center', marginBottom: '16px' }}>
    <label style={{ flex: '1', marginBottom: '0' }}>
      {label} {star && <span style={{ color: 'red' }}>*</span>}
    </label>
    <FormControlLabel
      control={
        <Checkbox
          name={name}
          value={value}
          onChange={onChange}
          checked={checked}
          sx={{ color: 'lightgrey', '&.Mui-checked': { color: 'green' } }}
        />
      }
      style={{ flex: '1.7', marginBottom: '0', marginLeft: '8px' }}
    />
  </div>
);

export default CustomCheckbox;
